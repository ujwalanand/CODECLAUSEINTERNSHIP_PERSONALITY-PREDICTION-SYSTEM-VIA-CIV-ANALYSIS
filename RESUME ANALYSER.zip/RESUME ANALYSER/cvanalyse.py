from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import pandas as pd

# Sample data (replace with real data)
cv_data = [
    "Experienced data scientist with expertise in machine learning and AI.",
    "Motivated software engineer with a strong background in development and project management."
]

# Labels for training (0 - introvert, 1 - extrovert)
labels = [0, 1]

# Preprocess and extract features
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(cv_data)
Ō
# Train model
model = LogisticRegression()
model.fit(X, labels)

# Predict on new CVs
new_cv = ["A passionate developer with leadership skills and team collaboration."]
X_new = vectorizer.transform(new_cv)
prediction = model.predict(X_new)

print("Predicted Personality:", "Extrovert" if prediction[0] == 1 else "Introvert")
